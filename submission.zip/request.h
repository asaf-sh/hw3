#ifndef __REQUEST_H__
#include "server.h"
void requestHandle(int fd, Req req, TStats* tstats);

#endif
